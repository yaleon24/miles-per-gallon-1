#include <iostream>

using namespace std;

int main()
{
    int miles, gallons, milespergallons;
    float tripcost, gasprice=2.50;
    cout << "How many miles were driven?" << endl;
    cin >> miles;

    cout << "How many gallons were used?" <<endl;
    cin>> gallons;
    milespergallons=miles/gallons;
    tripcost=gallons*gasprice;
    cout << "Your mpg was " <<milespergallons<<endl;
    cout << "You spent $"<<tripcost<<endl;
    return 0;
}
